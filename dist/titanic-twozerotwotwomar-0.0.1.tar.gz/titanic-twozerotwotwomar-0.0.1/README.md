# mlops_practice1_titanic
Initial repo for mlops practice
